package com.itsolutions.dao;

public interface NosotrosDao {
    
}
