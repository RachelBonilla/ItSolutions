package com.itsolutions;


import java.util.Locale;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;


@Configuration
public class ProjectConfig implements WebMvcConfigurer {
    /* Los siguientes métodos son para incorporar el tema de internacionalización en el proyecto */

    /* localeResolver se utiliza para crear una sesión de cambio de idioma */
    @Bean
    public LocaleResolver localeResolver() {
        var slr = new SessionLocaleResolver();
        slr.setDefaultLocale(Locale.getDefault());
        slr.setLocaleAttributeName("session.current.locale");
        slr.setTimeZoneAttributeName("session.current.timezone");

        return slr;
    }

    /* localeChangeInterceptor se utiliza para crear un interceptor de cambio de idioma */
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        var lci = new LocaleChangeInterceptor();
        lci.setParamName("lang");
        return lci;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
    }

    //Bean para poder acceder a los Messages.properties en código Java...
    @Bean("messageSource")
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource= new ResourceBundleMessageSource();
        messageSource.setBasenames("messages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
     @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    public void configurerGlobal(AuthenticationManagerBuilder build) throws Exception {
        build.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
    }
    
          @Override
    public void addViewControllers(ViewControllerRegistry registry) {
       
        registry.addViewController("/index").setViewName("index");
        registry.addViewController("/iniciarSesion").setViewName("iniciarSesion");
        registry.addViewController("/registro/nuevo").setViewName("/registro/nuevo");
 }
    @Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
        .authorizeHttpRequests((request) -> request
            // Rutas accesibles sin autenticación (públicas)
            .requestMatchers("/", "/index", "/errores/**", "/nosotros/**", "/soluciones/**", "/soporte/**", "/js/**", "/webjars/**")
            .permitAll() // Permitir acceso a estas rutas sin autenticación

            // Rutas accesibles solo para usuarios autenticados (protegidas)
            .requestMatchers("/iniciarSesion") // Esta ruta es para iniciar sesión, solo la verán los usuarios no autenticados
            .permitAll() 

            // Rutas protegidas por roles (solo ADMIN puede acceder a las páginas de administración)
            .requestMatchers("/contacto")
            .permitAll() // Contacto se puede ver sin estar autenticado

            // Rutas estáticas (imágenes, JS y CSS) se permiten sin autenticación
            .requestMatchers("/imagenes/**", "/css/**", "/js/**")
            .permitAll() 
        )
        .formLogin((form) -> form
            .loginPage("/iniciarSesion") // Página personalizada para login
            .permitAll() // Permitir acceso al login sin autenticación
        
         )
                .formLogin((form) -> form
                .loginPage("/iniciarSesion").permitAll())
                .logout((logout) -> logout.permitAll());
        return http.build();
    }
}


